conda create -n myenv python=3.6.2
source activate myenv
pip install nltk
python Ehsani_Sina_HW2.py